from ibm_watson import ToneAnalyzerV3
import os
from dotenv import load_dotenv,find_dotenv
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator


def analyseTone(context):
    # 
    authenticator = IAMAuthenticator(os.environ.get("TONE_ANALYSER_AUTHENTICATOR_KEY"))
    tone_analyzer = ToneAnalyzerV3(
        version='2017-09-21',
        authenticator=authenticator
    )

    tone_analyzer.set_service_url('https://api.eu-gb.tone-analyzer.watson.cloud.ibm.com/instances/fbff7ee5-2e11-4764-8066-93c6f49d5a06')

    text = context
    # print(text)
    tone_analysis = tone_analyzer.tone(
        {'text': text},
        content_type='application/json'
    ).get_result()
    # print(json.dumps(tone_analysis, indent=2))
    tone='Neutral'
    tone_analysis=tone_analysis['document_tone']['tones']
    # print(toneAnalysis)
    if len(tone_analysis)>0:
        tone=tone_analysis[0]['tone_name']
    return tone

