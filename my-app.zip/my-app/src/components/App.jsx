import React from "react";
import Chat from './Chatbox'


function App(){
    return (
        <div>
            <Chat/>
        </div>
    );
}

export default App;